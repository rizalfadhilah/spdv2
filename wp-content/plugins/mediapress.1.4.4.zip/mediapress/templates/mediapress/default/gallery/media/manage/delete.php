<?php
// Exit if the file is accessed directly over web
if ( ! defined( 'ABSPATH' ) ) {
	exit; 
}
/**
 * Delete media
 * Never Used
 * 
 */?>
<?php _e( 'Delete media.', 'mediapress' );?>