<?php
// Dear Developer,
// Thank you for looking at me
// Congratulations, you just wasted 8 seconds of your life.
// Now, you can close me and look at other files for details or
// if you are interested to know why am I here and what is the purpose?
// let me waste another 30 seconds of your life by making you read all my meaningless comments.

// Ok, I will tell ya. I am here to avoid people from directly peeking into the diretory and listing files.
// My brothers and sisters which don't speak much like me, are guarding all other directories just like me.
// You can think of us as the Samurai saving you the troubles.
/**
 * Have a hot cup of coffee and enjoy!
               ; ,
           ) ;( (
          ( (  ) ;
           ,-"""-.
        ,-|`-...-'|
       ((_|       |
        `-\       /
           `.___.'
 * 
 * 
 */